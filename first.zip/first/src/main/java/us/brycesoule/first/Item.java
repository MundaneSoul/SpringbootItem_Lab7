package us.brycesoule.first;

public class Item {
    private String itemName;
    private String supplier;
    private Double price;
    private Double quantity;
    public Item(String itemName, String supplier, Double price, Double quantity) {
        this.itemName = itemName;
        this.supplier = supplier;
        this.price = price;
        this.quantity = quantity;
    }
    public String getItemName() {
        return itemName;
    }
    public String getSupplier() {
        return supplier;
    }
    public Double getPrice(){return price;}
    public Double getQuantity(){return quantity;}
}