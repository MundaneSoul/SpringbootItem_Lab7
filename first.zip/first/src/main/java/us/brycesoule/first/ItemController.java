package us.brycesoule.first;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ItemController {
    @RequestMapping("/items")
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        items.add(new Item("Classic French Roast","Intelligensia", 12.99, 1.0));
        items.add(new Item("Dark Roast Special","Intelligensia", 14.99, 1.0));
        items.add(new Item("Hazelneuss Espresso","Jo Black", 20.99, 1.0));
        items.add(new Item("Morning Brew","Backmountain Coffe Co.", 15.95, 1.0));
        items.add(new Item("Deathroast Bean","Deathbrew Coffee", 19.99, 1.0));
        items.add(new Item("Styrofoam Cups","Uline", 8.50, 50.00));
        items.add(new Item("Heartland Coffee Mug","Nam Ping Ho Manufacturing", 19.50, 1.0));
        items.add(new Item("Heartland Coffee Designer Thermos","Nam Ping Ho Manufacturing", 23.50, 1.0));
        items.add(new Item("Supreme Cream: Vanilla","Deathbrew Coffee", 12.50, 1.0));
        items.add(new Item("Supreme Cream: Hazlenut","Deathbrew Coffee", 12.50, 1.0));

        return items;
    }
}